const mongoose = require('mongoose');
const Course = require('../models/Course');
const Category = require('../models/Category');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const getCourseOr404 = async (id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) throw new ApiError('Course not found', 404);
  const course = await Course.findById(id).populate('category');
  if (!course) throw new ApiError('Course not found', 404);
  return course;
};

const ensureCategoryExists = async (categoryId) => {
  if (!mongoose.Types.ObjectId.isValid(categoryId)) throw new ApiError('Category not found', 404);
  const category = await Category.findById(categoryId);
  if (!category) throw new ApiError('Category not found', 404);
};

const createCourse = asyncHandler(async (req, res) => {
  const { title, description, category, price, instructor } = req.body;
  await ensureCategoryExists(category);
  const course = await Course.create({ title, description, category, price, instructor });
  await course.populate('category');
  res.status(201).json({ success: true, message: 'Course created successfully', data: { course } });
});

const getCourses = asyncHandler(async (req, res) => {
  const page = req.query.page || 1;
  const limit = req.query.limit || 10;
  const filter = req.query.category ? { category: req.query.category } : {};
  const [courses, total] = await Promise.all([
    Course.find(filter).populate('category').sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    Course.countDocuments(filter)
  ]);
  res.status(200).json({
    success: true,
    message: 'Courses retrieved successfully',
    data: { courses, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } }
  });
});

const getCourse = asyncHandler(async (req, res) => {
  const course = await getCourseOr404(req.params.id);
  res.status(200).json({ success: true, message: 'Course retrieved successfully', data: { course } });
});

const updateCourse = asyncHandler(async (req, res) => {
  const course = await getCourseOr404(req.params.id);
  const allowedFields = ['title', 'description', 'category', 'price', 'instructor'];
  if (req.body.category !== undefined) await ensureCategoryExists(req.body.category);
  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) course[field] = req.body[field];
  });
  await course.save();
  await course.populate('category');
  res.status(200).json({ success: true, message: 'Course updated successfully', data: { course } });
});

const deleteCourse = asyncHandler(async (req, res) => {
  const course = await getCourseOr404(req.params.id);
  await course.deleteOne();
  res.status(200).json({ success: true, message: 'Course deleted successfully', data: null });
});

module.exports = { createCourse, getCourses, getCourse, updateCourse, deleteCourse };
