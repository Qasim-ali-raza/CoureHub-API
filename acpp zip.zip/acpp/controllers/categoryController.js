const mongoose = require('mongoose');
const Category = require('../models/Category');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const getCategoryOr404 = async (id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) throw new ApiError('Category not found', 404);
  const category = await Category.findById(id);
  if (!category) throw new ApiError('Category not found', 404);
  return category;
};

const createCategory = asyncHandler(async (req, res) => {
  const category = await Category.create({ name: req.body.name, description: req.body.description });
  res.status(201).json({ success: true, message: 'Category created successfully', data: { category } });
});

const getCategories = asyncHandler(async (req, res) => {
  const categories = await Category.find().sort({ createdAt: -1 });
  res.status(200).json({ success: true, message: 'Categories retrieved successfully', data: { categories } });
});

const getCategory = asyncHandler(async (req, res) => {
  const category = await getCategoryOr404(req.params.id);
  res.status(200).json({ success: true, message: 'Category retrieved successfully', data: { category } });
});

const updateCategory = asyncHandler(async (req, res) => {
  const category = await getCategoryOr404(req.params.id);
  if (req.body.name !== undefined) category.name = req.body.name;
  if (req.body.description !== undefined) category.description = req.body.description;
  await category.save();
  res.status(200).json({ success: true, message: 'Category updated successfully', data: { category } });
});

const deleteCategory = asyncHandler(async (req, res) => {
  const category = await getCategoryOr404(req.params.id);
  await category.deleteOne();
  res.status(200).json({ success: true, message: 'Category deleted successfully', data: null });
});

module.exports = { createCategory, getCategories, getCategory, updateCategory, deleteCategory };
