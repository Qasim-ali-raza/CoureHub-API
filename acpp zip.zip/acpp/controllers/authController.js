const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const generateToken = require('../utils/generateToken');

const authResponse = (res, statusCode, message, user) => {
  res.status(statusCode).json({
    success: true,
    message,
    data: { user, token: generateToken(user._id.toString()) }
  });
};

const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const existingUser = await User.findOne({ email });
  if (existingUser) throw new ApiError('An account with this email already exists', 409);

  const user = await User.create({ name, email, password });
  authResponse(res, 201, 'User registered successfully', user);
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    throw new ApiError('Invalid email or password', 401);
  }

  authResponse(res, 200, 'Login successful', user);
});

const getMe = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, message: 'Current user retrieved', data: { user: req.user } });
});

module.exports = { register, login, getMe };
