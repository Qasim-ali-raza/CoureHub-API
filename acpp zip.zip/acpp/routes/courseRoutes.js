const express = require('express');
const controller = require('../controllers/courseController');
const { protect } = require('../middleware/authMiddleware');
const validate = require('../middleware/validateMiddleware');
const { createCourseValidation, updateCourseValidation, listCourseValidation } = require('../validators/courseValidators');

const router = express.Router();

router.route('/')
  .post(protect, createCourseValidation, validate, controller.createCourse)
  .get(listCourseValidation, validate, controller.getCourses);

router.route('/:id')
  .get(controller.getCourse)
  .put(protect, updateCourseValidation, validate, controller.updateCourse)
  .delete(protect, controller.deleteCourse);

module.exports = router;
