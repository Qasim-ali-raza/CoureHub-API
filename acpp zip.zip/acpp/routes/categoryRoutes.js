const express = require('express');
const controller = require('../controllers/categoryController');
const { protect } = require('../middleware/authMiddleware');
const validate = require('../middleware/validateMiddleware');
const { createCategoryValidation, updateCategoryValidation } = require('../validators/categoryValidators');

const router = express.Router();

router.route('/')
  .post(protect, createCategoryValidation, validate, controller.createCategory)
  .get(controller.getCategories);

router.route('/:id')
  .get(controller.getCategory)
  .put(protect, updateCategoryValidation, validate, controller.updateCategory)
  .delete(protect, controller.deleteCategory);

module.exports = router;
