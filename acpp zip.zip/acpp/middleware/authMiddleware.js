const jwt = require('jsonwebtoken');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const protect = asyncHandler(async (req, res, next) => {
  const authorization = req.headers.authorization || '';
  if (!authorization.startsWith('Bearer ')) {
    throw new ApiError('Not authorized. Provide a Bearer token.', 401);
  }

  if (!process.env.JWT_SECRET) {
    throw new ApiError('JWT_SECRET is not configured.', 500);
  }

  try {
    const token = authorization.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) throw new ApiError('User for this token no longer exists.', 401);
    req.user = user;
    next();
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError('Not authorized. Token is invalid or expired.', 401);
  }
});

module.exports = { protect };
