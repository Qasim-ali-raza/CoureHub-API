# University Course REST API

A modular MVC REST API for authentication, categories, and courses. It uses Express, MongoDB/Mongoose, bcryptjs, JWT, and express-validator.

## Features and access rules

- Passwords are hashed with bcryptjs and excluded from all API responses.
- JWT authentication protects every category and course write operation (`POST`, `PUT`, `DELETE`) and `GET /api/auth/me`.
- Category and course `GET` routes are public so visitors can browse the catalog without signing in.
- Invalid or nonexistent resource IDs return `404`; invalid request input returns `400` with an `errors` array.

## Project structure

```text
project-root/
├── config/db.js
├── controllers/
│   ├── authController.js
│   ├── categoryController.js
│   └── courseController.js
├── middleware/
│   ├── authMiddleware.js
│   ├── errorMiddleware.js
│   └── validateMiddleware.js
├── models/
│   ├── Category.js
│   ├── Course.js
│   └── User.js
├── postman/University-Course-API.postman_collection.json
├── routes/
│   ├── authRoutes.js
│   ├── categoryRoutes.js
│   └── courseRoutes.js
├── utils/
│   ├── ApiError.js
│   ├── asyncHandler.js
│   └── generateToken.js
├── validators/
│   ├── authValidators.js
│   ├── categoryValidators.js
│   └── courseValidators.js
├── .env.example
├── .gitignore
├── package.json
└── server.js
```

## Setup and run

1. Install Node.js 18 or newer and ensure MongoDB is running locally.
2. Copy `.env.example` to `.env` and set a strong, private `JWT_SECRET`.
3. Install and run the app:

```bash
npm install
npm run dev
```

Use `npm start` for a non-reloading production-style start. The default server address is `http://localhost:5000`.

### Environment variables

```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/university_course_api
JWT_SECRET=replace_with_a_long_random_secret
JWT_EXPIRES_IN=7d
```

### MongoDB Atlas

Create a free cluster in MongoDB Atlas, create a database user, and add your current IP address in **Network Access**. In Atlas, choose **Connect > Drivers** and copy the connection string. Put it in `.env`, replacing the password and database name, for example:

```env
MONGODB_URI=mongodb+srv://YOUR_USER:YOUR_ENCODED_PASSWORD@cluster0.example.mongodb.net/university_course_api?retryWrites=true&w=majority
```

Do not commit `.env` or expose the Atlas password. URL-encode special password characters.

## Response format and authentication

Successful responses use `{ "success": true, "message": "...", "data": ... }`. Errors use `{ "success": false, "message": "...", "errors": [...] }`.

For protected routes, send this header:

```http
Authorization: Bearer <token>
```

The token is returned by register and login at `data.token`.

## Endpoints and example request bodies

### Authentication

| Method | Endpoint | Access | Body |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | Public | `name`, `email`, `password` |
| POST | `/api/auth/login` | Public | `email`, `password` |
| GET | `/api/auth/me` | Protected | None |

```json
{ "name": "Ayesha Khan", "email": "ayesha.khan@example.com", "password": "SecurePass123" }
```

```json
{ "email": "ayesha.khan@example.com", "password": "SecurePass123" }
```

### Categories

| Method | Endpoint | Access |
| --- | --- | --- |
| POST | `/api/categories` | Protected |
| GET | `/api/categories` | Public |
| GET | `/api/categories/:id` | Public |
| PUT | `/api/categories/:id` | Protected |
| DELETE | `/api/categories/:id` | Protected |

Create body:

```json
{ "name": "Computer Science", "description": "Programming and software development courses" }
```

Update body (all fields are optional):

```json
{ "description": "Updated description" }
```

### Courses

| Method | Endpoint | Access |
| --- | --- | --- |
| POST | `/api/courses` | Protected |
| GET | `/api/courses?page=1&limit=10` | Public |
| GET | `/api/courses?category=:categoryId` | Public |
| GET | `/api/courses/:id` | Public |
| PUT | `/api/courses/:id` | Protected |
| DELETE | `/api/courses/:id` | Protected |

Create body:

```json
{
  "title": "Node.js Fundamentals",
  "description": "Build REST APIs with Express and MongoDB.",
  "category": "PUT_CATEGORY_ID_HERE",
  "price": 49.99,
  "instructor": "Dr. Sara Ali"
}
```

First create a category. Copy its `_id` from `data.category._id` in the successful category response and paste it into the course request's `category` field. The included Postman collection does this automatically by saving it as `{{categoryId}}`.

`page` defaults to `1`, `limit` defaults to `10`, and the maximum limit is `100`.

## Postman collection

Import [postman/University-Course-API.postman_collection.json](postman/University-Course-API.postman_collection.json). The collection has a `baseUrl` variable set to `http://localhost:5000`. Its Register and Login test scripts save `data.token` to `{{token}}`; protected requests already send `Authorization: Bearer {{token}}`.

## Postman Evidence Checklist

For every screenshot, leave the Postman method/URL bar, the **Headers** area, and the lower response panel visible. Send requests in this order:

1. Send **Register** (201) and then **Login** (200). Capture the successful JSON response with `data.token` visible. This satisfies Screenshot 1; capture both requests if your instructor requires separate evidence.
2. Send **Create Category** with the token saved by Login. Confirm **201 Created** and capture it for Screenshot 2.
3. Send **List Categories**. Confirm **200 OK** and capture it for Screenshot 3.
4. Send **Create Category Validation Error**. It omits `name`; confirm **400 Bad Request** with `message: "Validation failed"` and a non-empty `errors` list. Capture Screenshot 4.
5. Send **Invalid Category ID (404)**, or **Unknown Route (404)**. Confirm **404 Not Found** and capture Screenshot 5. The unknown route response message is exactly `"Route not found"`.

## Exact terminal commands

```powershell
Copy-Item .env.example .env
# Edit .env and set JWT_SECRET before starting.
npm install
npm run dev
```
