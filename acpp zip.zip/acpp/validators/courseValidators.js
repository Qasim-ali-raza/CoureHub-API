const { body, query } = require('express-validator');

const courseFields = [
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty').isLength({ max: 200 }).withMessage('Title must be at most 200 characters'),
  body('description').optional().trim().notEmpty().withMessage('Description cannot be empty').isLength({ max: 2000 }).withMessage('Description must be at most 2000 characters'),
  body('category').optional().isMongoId().withMessage('Category must be a valid ObjectId'),
  body('price').optional().isFloat({ min: 0 }).withMessage('Price must be a number greater than or equal to 0').toFloat(),
  body('instructor').optional().trim().isLength({ max: 100 }).withMessage('Instructor must be at most 100 characters')
];

const createCourseValidation = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }).withMessage('Title must be at most 200 characters'),
  body('description').trim().notEmpty().withMessage('Description is required').isLength({ max: 2000 }).withMessage('Description must be at most 2000 characters'),
  body('category').notEmpty().withMessage('Category is required').isMongoId().withMessage('Category must be a valid ObjectId'),
  body('price').optional().isFloat({ min: 0 }).withMessage('Price must be a number greater than or equal to 0').toFloat(),
  body('instructor').optional().trim().isLength({ max: 100 }).withMessage('Instructor must be at most 100 characters')
];

const listCourseValidation = [
  query('category').optional().isMongoId().withMessage('Category must be a valid ObjectId'),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer').toInt(),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be an integer from 1 to 100').toInt()
];

module.exports = { createCourseValidation, updateCourseValidation: courseFields, listCourseValidation };
