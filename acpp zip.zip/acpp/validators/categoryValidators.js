const { body } = require('express-validator');

const categoryFields = [
  body('name').optional().trim().notEmpty().withMessage('Name cannot be empty').isLength({ max: 100 }).withMessage('Name must be at most 100 characters'),
  body('description').optional().trim().isLength({ max: 500 }).withMessage('Description must be at most 500 characters')
];

const createCategoryValidation = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }).withMessage('Name must be at most 100 characters'),
  body('description').optional().trim().isLength({ max: 500 }).withMessage('Description must be at most 500 characters')
];

const updateCategoryValidation = categoryFields;

module.exports = { createCategoryValidation, updateCategoryValidation };
